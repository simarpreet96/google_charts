from django.contrib import admin
from .models import Circle
from django.db import models


admin.site.register(Circle)
